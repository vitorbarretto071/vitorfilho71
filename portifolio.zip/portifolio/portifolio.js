const button = document.getElementById('darkmode-button');
        const body = document.body;
        
        button.addEventListener('click', () => {
            if (body.classList.contains('light-mode')) {
                body.classList.remove('light-mode');
                body.classList.add('dark-mode');
                localStorage.setItem('theme', 'dark');
                button.textContent = ' Light Mode';
            } else {
                body.classList.remove('dark-mode');
                body.classList.add('light-mode');
                localStorage.setItem('theme', 'light');
                button.textContent = ' Dark Mode';
            }
        });
        
        // Apply the saved theme on page load
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            body.classList.add(savedTheme === 'dark' ? 'Dark-mode' : 'light-mode');
            button.textContent = savedTheme === 'dark' ? ' Light Mode' : ' Dark Mode';
            
        }