const slider = document.querySelectorAll('.slider');
const slider2 = document.querySelectorAll('.slider2');
const slider3 = document.querySelectorAll('.slider3');
const btnPrev = document.getElementById('prev-button');
const btnNext = document.getElementById('next-button');
const btnPrev2 = document.getElementById('prev-button2');
const btnNext2 = document.getElementById('next-button2');
const btnPrev3 = document.getElementById('prev-button3');
const btnNext3 = document.getElementById('next-button3');

let currentSlide = 0;
//Primeira caixa de slides
function hideSlider(){
    slider.forEach(item => item.classList.remove('on'))
}

function showSlider(){
    slider[currentSlide].classList.add('on')
}
function nextSlider(){
    hideSlider()
    if(currentSlide == slider.length -1){
        currentSlide = 0
    }else{
        currentSlide++
    }
    showSlider()
}
function prevSlider(){
    hideSlider()
    if(currentSlide == 0){
        currentSlide = slider.length -1
    }else{
        currentSlide--
    }
    showSlider()
}

//Segunda caixa de slides
function hideSlider2(){
    slider2.forEach(item => item.classList.remove('on2'))
}

function showSlider2(){
    slider2[currentSlide].classList.add('on2')
}

function nextSlider2(){
    hideSlider2()
    if(currentSlide == slider2.length -1){
        currentSlide = 0
    }else{
        currentSlide++
    }
    showSlider2()
}
function prevSlider2(){
    hideSlider2()
    if(currentSlide == 0){
        currentSlide = slider2.length -1
    }else{
        currentSlide--
    }
    showSlider2()
}
//Terceira caixa de slides

function hideSlider3(){
    slider3.forEach(item => item.classList.remove('on3'))
}

function showSlider3(){
    slider3[currentSlide].classList.add('on3')
}
function nextSlider3(){
    hideSlider3()
    if(currentSlide == slider3.length -1){
        currentSlide = 0
    }else{
        currentSlide++
    }
    showSlider3()
}
function prevSlider3(){
    hideSlider3()
    if(currentSlide == 0){
        currentSlide = slider3.length -1
    }else{
        currentSlide--
    }
    showSlider3()
}



btnNext.addEventListener('click', nextSlider)
btnPrev.addEventListener('click', prevSlider)
btnNext2.addEventListener('click', nextSlider2)
btnPrev2.addEventListener('click', prevSlider2)
btnNext3.addEventListener('click', nextSlider3)
btnPrev3.addEventListener('click', prevSlider3)